
public class Question {
	String prompt;
	String answer;
	
	public Question(String prompt, String answer) {
		this.prompt = prompt;
		this.answer = answer;
		
	}

}
