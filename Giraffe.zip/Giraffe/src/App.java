import java.util.Scanner;

public class App {
	public static void main(String [] arg) { 
		
	String Q1 = "What colours are apples?\n"
			  + "(a)red/green\n(b)Orange\n(c)Magenta";
	
	String Q2 = "What colours are bananas?\\n"
			  + "(a)red/green\n(b)Yellow\n(c)Blue";
	
	Question [] questions = {
			 new Question(Q1, "a"),
			 new Question(Q2, "b")		 
	};
	takeTest(questions);
	
	
	}
	
	public static void takeTest(Question [] questions) {
		int score = 0;
		Scanner KeybourdInput = new Scanner(System.in);
		
		for(int i = 0; i < questions.length; i++) {
			System.out.println(questions [i].prompt);
			String answer = KeybourdInput.nextLine();
			if(answer.equals(questions[i].answer)) {
				score++;
			}
		}
	System.out.println("You got" + score + "/" + questions.length);
		
	}
		
	}

